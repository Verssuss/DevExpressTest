﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //(sender as Border).Background = new SolidColorBrush(Colors.Blue);
        }

        private void canvas_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                (sender as Canvas).Children.OfType<Ellipse>().ToList().ForEach(x=> (sender as Canvas).Children.Remove(x));
            }
            else
            {
                Ellipse ellipse = new Ellipse();
                ellipse.Fill = new SolidColorBrush(Colors.Green);
                ellipse.Width = 10;
                ellipse.Height = 10;
                ellipse.RenderTransform = new ScaleTransform();
                Canvas.SetLeft(ellipse, e.GetPosition(sender as Canvas).X - 5);
                Canvas.SetTop(ellipse, e.GetPosition(sender as Canvas).Y - 5);
                Canvas.SetZIndex(ellipse, -1);
                (sender as Canvas).Children.Add(ellipse);
                ellipse.RenderTransformOrigin = new Point(0.5d, 0.5d);
                var animation = new DoubleAnimation(border.Width / ellipse.Width * 3, TimeSpan.FromMilliseconds(1000));
                var animation2 = new DoubleAnimation(border.Height / ellipse.Height * 3, TimeSpan.FromMilliseconds(1000));
                //animation.EasingFunction = new BounceEase() { EasingMode = EasingMode.EaseOut };
                var sb = new Storyboard();
                sb.Children.Add(animation);
                sb.Children.Add(animation2);
                Storyboard.SetTarget(animation, ellipse);
                Storyboard.SetTarget(animation2, ellipse);
                Storyboard.SetTargetProperty(animation, new PropertyPath("(UIElement.RenderTransform).(ScaleTransform.ScaleX)"));
                Storyboard.SetTargetProperty(animation2, new PropertyPath("(UIElement.RenderTransform).(ScaleTransform.ScaleY)"));
                sb.Begin();
            }

        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("wadawd");

        }
    }
}
