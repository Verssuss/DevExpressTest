﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            IServiceCollection services = new ServiceCollection();
            services.AddSingleton<IMessenger, MessengerControl>();

            var provider = services.BuildServiceProvider();

            messenger = provider.GetService<IMessenger>();

            if (messenger is UIElement ui)
                grid.Children.Add(ui);
        }
        IMessenger messenger;

        private async void Success(object sender, RoutedEventArgs e)
        {
            messenger?.ShowMessage(new MyMessage() { Message = "СЛОНЫ́, сло­но­вые (Elephantidae), се­мей­ст­во мле­ко­пи­таю­щих отр. хо­бот­ных (Pro­boscidea). На­чи­ная с эо­це­на на­се­ля­ли поч­ти все кон­ти­нен­ты, кро­ме Ав­ст­ра­лии и Ан­тарк­ти­ды. Боль­шин­ст­во ро­дов и ви­дов се­мей­ст­ва вы­мер­ло. 2 совр. ро­да: аф­ри­кан­ские С. (Loxodonta) с дву­мя ви­да­ми: са­ван­ный (L. africana) и лес­ной (L. cyclotis) С., оби­таю­щие со­от­ветст­вен­но в са­ван­нах и тро­пич. ле­сах Аф­ри­ки к югу от Са­ха­ры, и ази­ат­ский С. с един­ст­вен­ным ви­дом ази­ат­ский, или ин­дий­ский, С. (Elephas maximus), ко­то­рый жи­вёт в джунг­лях Юж. и Юго-Вост. Азии. Са­мые круп­ные на­зем­ные мле­ко­пи­таю­щие (дли­на те­ла са­ван­но­го сло­на дос­ти­га­ет 7,5 м, выс. 4 м, мас­са 7,5 т). Но­ги мощ­ные, ко­лон­но­об­раз­ные. Мас­сив­ная го­ло­ва окан­чи­ва­ет­ся", TypeMessage = TypeMessage.Success });
        }
        private async void Error(object sender, RoutedEventArgs e)
        {
            messenger?.ShowMessage(new MyMessage() { Message = "Что же делать?", TypeMessage = TypeMessage.Error });
        }
        private async void Warning(object sender, RoutedEventArgs e)
        {
            messenger?.ShowMessage(new MyMessage() { Message = "Не лезь сука он тебя сожрет", TypeMessage = TypeMessage.Warning });
        }


    }

    public class AnimatedPanelBehavior
    {
        public static double GetAnimatedHeight(DependencyObject obj)
        {
            return (double)obj.GetValue(AnimatedHeightProperty);
        }

        public static void SetAnimatedHeight(DependencyObject obj, double value)
        {
            obj.SetValue(AnimatedHeightProperty, value);
        }

        public static readonly DependencyProperty AnimatedHeightProperty =
                 DependencyProperty.RegisterAttached("AnimatedHeight", typeof(double), typeof(AnimatedPanelBehavior), new UIPropertyMetadata(0d, new PropertyChangedCallback((s, e) =>
                 {
                     FrameworkElement sender = s as FrameworkElement;
                     sender.Height = (double)e.NewValue;
                 })));
    }

    public class ConsoleMessenger : IMessenger
    {
        public List<int>? Items { get; set; }

        public ConsoleMessenger()
        {
            Items = Enumerable.Range(0, 10).Select(x => x).ToList();
        }

        public void ShowMessage(IMessage message)
        {
            throw new NotImplementedException();
        }
    }
}
